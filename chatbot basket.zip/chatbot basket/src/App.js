import React, { useState, useEffect } from 'react';
import ChatBot from 'react-simple-chatbot';
import { ThemeProvider } from 'styled-components';

const steps = [
  {
    id: '1',
    message: "Bienvenue sur le Chatbot. Comment puis-je vous aider aujourd\'hui?",
    trigger: 'menu',
  },
  {
    id: 'menu',
    options: [
      { value: 1, label: 'Nos Baskets', trigger: 'features' },
      { value: 2, label: 'pourquoi choisir nos Basket ', trigger: 'benefits' },
      { value: 3, label: 'Information', trigger: 'info' },
      { value: 4, label: 'Contact', trigger: 'contact' },
    ],
  },
  {
    id: 'features',
    message: ' Nike Air Force 1 \Adidas Yeezy Boost 350 \nJordan 1 Retro High \nConverse Chuck Taylor All Star \nNike Air Max 90',
    trigger: 'menu',
  },
  {
    id: 'benefits',
    message: 'Nous proposons une large gamme de baskets tendances, avec des prix concurrentiels.',
    trigger: 'menu',
  },
  {
    id: 'info',
    message: 'Ce chatbot à été conçu par Izac, Bill et Timothé  dans le but d aider tous les utilisateurs.',
    trigger: 'menu',
  },
  {
    id: 'contact',
    message: 'Pour plus d\'informations, vous pouvez nous contacter à... ou nous appeler au +33 (0)0 00 00 06 00.',
    trigger: 'menu',
  },
];



const theme = {
  background: '#f5f8fb',
  fontFamily: 'Helvetica Neue',
  headerBgColor: '#1c56df',
  headerFontColor: '#fff',
  headerFontSize: '15px',
  botBubbleColor: '#1c56df',
  botFontColor: '#fff',
  userBubbleColor: '#fff',
  userFontColor: '#4a4a4a',
};

function App() {
  return (
        
          <>  
          <ThemeProvider theme={theme}>
            <ChatBot
              headerTitle="Basket Chatbot"
              recognitionEnable={true}
              steps={steps}
              floating
            />
          </ThemeProvider>      
          </>
        
      )}
export default App;
